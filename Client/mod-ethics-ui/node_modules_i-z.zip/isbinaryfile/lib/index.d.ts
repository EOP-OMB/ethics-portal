/// <reference types="node" />
export declare function isBinaryFile(file: string | Buffer, size?: number): Promise<boolean>;
export declare function isBinaryFileSync(file: string | Buffer, size?: number): boolean;
