import * as i0 from "@angular/core";
import * as i1 from "./accordion";
import * as i2 from "./accordion-item";
export declare class CdkAccordionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdkAccordionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdkAccordionModule, [typeof i1.CdkAccordion, typeof i2.CdkAccordionItem], never, [typeof i1.CdkAccordion, typeof i2.CdkAccordionItem]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdkAccordionModule>;
}
