import * as i0 from "@angular/core";
import * as i1 from "./dir";
export declare class BidiModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BidiModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BidiModule, [typeof i1.Dir], never, [typeof i1.Dir]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BidiModule>;
}
